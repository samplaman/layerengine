/* ==========================================================================
   LAYERENGINE INTERACTIVITY & ANIMATION
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

    /* ==========================================================================
       1. TABS SYSTEM
       ========================================================================== */
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');

            // Remove active classes
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));

            // Add active classes to targets
            button.classList.add('active');
            const activePane = document.getElementById(targetTab);
            if (activePane) activePane.classList.add('active');
        });
    });



    /* ==========================================================================
       3. DOWNLOADS & INSTALLATION MODAL
       ========================================================================== */
    const modal = document.getElementById('installerModal');
    const modalContent = document.getElementById('modalContent');
    const openModalButtons = document.querySelectorAll('.open-modal-btn');
    const closeModalButtons = document.querySelectorAll('.close-modal-btn');

    // Data structured to provide perfect installation steps
    const platformData = {
        windows: {
            title: 'Windows Installation',
            steps: [
                {
                    title: 'Run Installer Package',
                    desc: 'Download the lightweight NSIS installer executable <code>LayerEngine-Installer.exe</code> and double-click to run it.'
                },
                {
                    title: 'Administrator Permission',
                    desc: 'The installer operates with elevated administrator permissions to deploy the VST3 plugin bundle to the common directories.'
                },
                {
                    title: 'Directories Deployed',
                    desc: 'The installer deploys the Standalone App to <code>C:\\Program Files\\LayerEngine\\LayerEngine.exe</code> and copies the <code>LayerEngine.vst3</code> plugin package directly into your DAW folder: <code>C:\\Program Files\\Common Files\\VST3\\</code>.'
                },
                {
                    title: 'Launch DAW',
                    desc: 'Open your host sequencer (e.g. Ableton Live, FL Studio, Cubase) and run a plug-in rescan. Load LayerEngine on any audio/MIDI track!'
                }
            ]
        },
        macos: {
            title: 'macOS Installation',
            steps: [
                {
                    title: 'Open Flat Installer Package',
                    desc: 'Double-click the Apple certified <code>LayerEngine-Installer.pkg</code> installer package.'
                },
                {
                    title: 'System Directories Targeted',
                    desc: 'The installer securely extracts and distributes:<ul><li>Standalone App to: <code>/Applications/LayerEngine.app</code></li><li>VST3 Plugin to: <code>/Library/Audio/Plug-Ins/VST3/LayerEngine.vst3</code></li><li>AU Component to: <code>/Library/Audio/Plug-Ins/Components/LayerEngine.component</code></li></ul>'
                },
                {
                    title: 'DAW Integration',
                    desc: 'Restart your DAW (e.g. Logic Pro, Reaper, Ableton Live) to rescan components. In Logic Pro, it will register as an Audio Unit Instrument.'
                }
            ]
        },
        linux: {
            title: 'Linux Installation',
            steps: [
                {
                    title: 'Standard Debian Package (.deb)',
                    desc: 'If you are running Ubuntu, Debian, or Linux Mint, double-click the <code>LayerEngine-Installer.deb</code> package or install it via the terminal: <div class="code-box">sudo dpkg -i LayerEngine-Installer.deb</div>'
                },
                {
                    title: 'Desktop Launcher & Audio Icon',
                    desc: 'The Debian package registers standalone application launchers automatically in <code>/usr/bin/LayerEngine</code> and copies system-wide shortcuts to <code>/usr/share/applications/</code>.'
                },
                {
                    title: 'Universal Portable Install',
                    desc: 'If you are on non-Debian distributions (Arch, Fedora, openSUSE), unzip the universal archive and execute the installer script inside a terminal:<div class="code-box">chmod +x install.sh<br>./install.sh</div>'
                },
                {
                    title: 'Local Install (Non-Root Option)',
                    desc: 'Running the universal installer without <code>sudo</code> automatically copies VST3 plugins to your home directory: <code>~/.vst3/</code> and links standalone binaries locally: <code>~/.local/bin/</code>.'
                }
            ]
        }
    };

    function openModal(platformKey) {
        const data = platformData[platformKey];
        if (!data) return;

        let stepsHTML = '';
        data.steps.forEach((step, idx) => {
            stepsHTML += `
                <div class="instruction-step">
                    <div class="step-number">${idx + 1}</div>
                    <div class="step-details">
                        <h4>${step.title}</h4>
                        <p>${step.desc}</p>
                    </div>
                </div>
            `;
        });

        modalContent.innerHTML = `
            <div class="modal-header">
                <h2>${data.title} <span>Guide</span></h2>
                <p>Follow the simple steps to set up LayerEngine on your system:</p>
            </div>
            <div class="modal-body">
                ${stepsHTML}
            </div>
            <div style="text-align: center; margin-top: 2rem;">
                <button class="btn btn-primary close-modal-action-btn">Done, let's play</button>
            </div>
        `;

        modal.classList.add('active');

        // Add action for the secondary close button inside content
        const actionBtn = modalContent.querySelector('.close-modal-action-btn');
        if (actionBtn) {
            actionBtn.addEventListener('click', closeModal);
        }
    }

    function closeModal() {
        modal.classList.remove('active');
    }

    openModalButtons.forEach(button => {
        button.addEventListener('click', () => {
            const platform = button.getAttribute('data-platform');
            openModal(platform);
        });
    });

    closeModalButtons.forEach(button => {
        button.addEventListener('click', closeModal);
    });

    // Close on overlay click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Close on Escape key
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });

});
